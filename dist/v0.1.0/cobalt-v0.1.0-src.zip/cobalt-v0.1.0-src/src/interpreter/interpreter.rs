use crate::interpreter::values;
use crate::interpreter::environment;
use crate::parser::ast;

use super::values::mk_null;
use super::values::mk_number;

pub fn eval_program(program: &ast::Program, env: &mut environment::environment::Environment) -> Box<dyn values::RuntimeVal> {
    let mut last_evaluated: Box<dyn values::RuntimeVal> = mk_null();
    for statement in &program.body {
        last_evaluated = evaluate(statement.as_ref(), env);
    }
    last_evaluated
}

fn eval_numeric_binary_expr(lhs: &values::NumberVal, rhs: &values::NumberVal, operator: &str) -> values::NumberVal {
    let result: f64 = match operator {
        "+" => lhs.value + rhs.value,
        "-" => lhs.value - rhs.value,
        "*" => lhs.value * rhs.value,
        "/" => lhs.value / rhs.value,
        _ => panic!("Interpretation Error: Invalid operator `{}`, please report this if you did not expect this error.", operator),
    };

    values::NumberVal {
        val_type: values::ValueType::Number,
        value: result,
    }
}

fn eval_binary_expr(binop: &ast::BinaryExpr, env: &mut environment::environment::Environment) -> Box<dyn values::RuntimeVal> {
    let lhs = evaluate(binop.left.as_ref(), env);
    let rhs = evaluate(binop.right.as_ref(), env);
    if lhs.val_type() == values::ValueType::Number && rhs.val_type() == values::ValueType::Number {
        let lhs_number = lhs.as_any().downcast_ref::<values::NumberVal>().unwrap();
        let rhs_number = rhs.as_any().downcast_ref::<values::NumberVal>().unwrap();
        Box::new(eval_numeric_binary_expr(lhs_number, rhs_number, &binop.operator))
    } else {
        values::mk_null()
    }
}

fn evaluate_numeric_literal(node: &ast::NumericLiteral) -> Box<dyn values::RuntimeVal> {
    let value = node.value.parse::<f64>().expect("Failed to parse numeric literal");
    mk_number(value)
}

fn evaluate_assignment(node: &ast::AssignmentExpr, env: &mut environment::environment::Environment) -> Box<dyn values::RuntimeVal> {
    if node.assignee.kind() != ast::NodeType::Identifier {
        panic!("Interpretation Error: Invalid assignee in the assignment expression. ");
    }

    let varname_ident = node.assignee.as_any().downcast_ref::<ast::Identifier>()
        .expect("Expected an identifier for the variable name.");
    let varname = varname_ident.symbol.clone();
    let evaluated = evaluate(&*node.value, env);
    env.assign_var(varname, evaluated)
        .expect("Failed to assign value to variable.")
}

pub fn evaluate(ast_node: &dyn ast::Node, env: &mut environment::environment::Environment) -> Box<dyn values::RuntimeVal> {
    match ast_node.kind() {
        ast::NodeType::Identifier => {
            let identifier = ast_node.as_any().downcast_ref::<ast::Identifier>().expect("Expected Identifier");
            env.lookup_var(identifier.symbol.clone()).expect("Failed to lookup variable.")
        }
        ast::NodeType::NumericLiteral => {
            let num_node = ast_node.as_any().downcast_ref::<ast::NumericLiteral>().expect("Expected NumericLiteral");
            evaluate_numeric_literal(num_node)
        },
        ast::NodeType::BinaryExpr => {
            let binop = ast_node.as_any().downcast_ref::<ast::BinaryExpr>().expect("Expected BinaryExpr");
            eval_binary_expr(binop, env)
        },
        ast::NodeType::Program => {
            let program = ast_node.as_any().downcast_ref::<ast::Program>().expect("Expected Program");
            eval_program(program, env)
        },
        ast::NodeType::VarDeclaration => {
            let declaration = ast_node.as_any().downcast_ref::<ast::VarDeclaration>().expect("Expected VarDeclaration");
            let value = evaluate(&*declaration.value, env);
            env.declare_var(declaration.identifier.clone(), value, declaration.constant)
            .expect("Declaration of variable failed")
        }
        ast::NodeType::AssignmentExpr => {
            let assignment = ast_node.as_any().downcast_ref::<ast::AssignmentExpr>().expect("Expected AssignmentExpr");
            evaluate_assignment(assignment, env)
        }
        // _ => panic!("Interpretation Error: Unsupported AST node type."),
    }
}
