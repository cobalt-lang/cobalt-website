use std::collections::{HashMap, HashSet};
use std::rc::Rc;
use std::cell::RefCell;

use crate::interpreter::values::RuntimeVal;

pub struct Environment {
    parent: Option<Rc<RefCell<Environment>>>,
    variables: HashMap<String, Box<dyn RuntimeVal>>,
    constants: HashSet<String>,
}

impl Environment {
    pub fn new(parent_env: Option<Rc<RefCell<Environment>>>) -> Self {
        Environment {
            parent: parent_env,
            variables: HashMap::new(),
            constants: HashSet::new(),
        }
    }

    pub fn declare_var(&mut self, varname: String, value: Box<dyn RuntimeVal>, constant: bool) -> Result<Box<dyn RuntimeVal>, String> {
        if self.variables.contains_key(&varname) {
            return Err(format!("Cannot declare variable {}. As it already is defined.", varname));
        }
        self.variables.insert(varname.clone(), value.clone());
        if constant {
            self.constants.insert(varname.clone());
        }
        Ok(value)
    }

    pub fn assign_var(&mut self, varname: String, value: Box<dyn RuntimeVal>) -> Result<Box<dyn RuntimeVal>, String> {
        if self.constants.contains(&varname) {
            panic!("Cannot reassign the variable '{}' as it is a constant.", varname);
        }


        match self.resolve(varname.clone()) {
            Ok(env_ref) => {
                env_ref.borrow_mut().variables.insert(varname, value.clone());
                Ok(value)
            },
            Err(e) => Err(e),
        }
    }

    pub fn lookup_var(&self, varname: String) -> Result<Box<dyn RuntimeVal>, String> {
        match self.resolve(varname.clone()) {
            Ok(env_ref) => {
                env_ref.borrow().variables.get(&varname)
                    .cloned()
                    .ok_or_else(|| format!("Variable '{}' not found", varname))
            },
            Err(e) => Err(e),
        }
    }

    pub fn resolve(&self, varname: String) -> Result<Rc<RefCell<Environment>>, String> {
        if self.variables.contains_key(&varname) {
            return Ok(Rc::new(RefCell::new(self.clone())));
        }
        if let Some(parent) = &self.parent {
            return parent.borrow().resolve(varname);
        }
        Err(format!("Cannot resolve '{}' as it does not exist.", varname))
    }
}

impl Clone for Environment {
    fn clone(&self) -> Self {
        Environment {
            parent: self.parent.clone(),
            variables: self.variables.clone(),
            constants: self.constants.clone(),
        }
    }
}