use std::any::Any;

#[derive(Clone, Debug, PartialEq)]
pub enum ValueType {
    Null,
    Number,
    Boolean,
}

pub trait RuntimeVal: std::fmt::Debug + Any {
    fn val_type(&self) -> ValueType;
    fn as_any(&self) -> &dyn Any;
    fn clone_box(&self) -> Box<dyn RuntimeVal>;
}

impl Clone for Box<dyn RuntimeVal> {
    fn clone(&self) -> Self {
        self.clone_box()
    }
}

#[derive(Clone, Debug)]
pub struct NullVal {
    pub val_type: ValueType,
    pub value: String,
}

impl RuntimeVal for NullVal {
    fn val_type(&self) -> ValueType {
        self.val_type.clone()
    }

    fn as_any(&self) -> &dyn Any {
        self
    }

    fn clone_box(&self) -> Box<dyn RuntimeVal> {
        Box::new(self.clone())
    }
}

#[derive(Clone, Debug)]
pub struct NumberVal {
    pub val_type: ValueType,
    pub value: f64,
}

impl RuntimeVal for NumberVal {
    fn val_type(&self) -> ValueType {
        self.val_type.clone()
    }

    fn as_any(&self) -> &dyn Any {
        self
    }

    fn clone_box(&self) -> Box<dyn RuntimeVal> {
        Box::new(self.clone())
    }
}

#[derive(Clone, Debug)]
pub struct BooleanVal {
    pub val_type: ValueType,
    pub value: bool,
}

impl RuntimeVal for BooleanVal {
    fn val_type(&self) -> ValueType {
        self.val_type.clone()
    }

    fn as_any(&self) -> &dyn Any {
        self
    }

    fn clone_box(&self) -> Box<dyn RuntimeVal> {
        Box::new(self.clone())
    }
}

pub fn mk_null() -> Box<dyn RuntimeVal> {
    Box::new(NullVal { val_type: ValueType::Null, value: "null".to_string() })
}

pub fn mk_number(value: f64) -> Box<dyn RuntimeVal> {
    Box::new(NumberVal { val_type: ValueType::Number, value })
}

pub fn mk_bool(value: bool) -> Box<dyn RuntimeVal> {
    Box::new(BooleanVal { val_type: ValueType::Boolean, value })
}