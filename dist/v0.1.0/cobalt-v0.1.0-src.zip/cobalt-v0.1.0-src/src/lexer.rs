#[derive(Debug, PartialEq, Clone)]
pub enum TokenType {
    // keywords
    Let,
    Const,

    // binary operators
    BinaryOperator,
    Equals,
    OpenParen,
    CloseParen,


    // literals

    Number,
    Identifier,
    
    // misc
    EOF,
}

#[derive(Debug, PartialEq, Clone)]
pub struct Token {
    pub value: String,
    pub tokentype: TokenType,
}

fn return_token(tokentype: TokenType, value: String) -> Token {
    Token {
        value,
        tokentype,
    }
}

fn is_letter(c: char) -> bool {
    c.is_ascii_alphabetic()
}

fn is_digit(c: char) -> bool {
    c.is_ascii_digit()
}

pub fn lexer(input: &str) -> Vec<Token> {
    let mut tokens = Vec::new();
    let chars: Vec<char> = input.chars().collect();
    let mut i = 0;

    while i < chars.len() {
        match chars[i] {
            ' ' | '\t' | '\n' => {
                i += 1; // Skip whitespace
            }
            '+' | '-' | '/' | '*' => {
                tokens.push(return_token(TokenType::BinaryOperator, chars[i].to_string()));
                i += 1;
            }
            '=' => {
                tokens.push(return_token(TokenType::Equals, chars[i].to_string()));
                i += 1;
            }
            '(' => {
                tokens.push(return_token(TokenType::OpenParen, "(".to_string()));
                i += 1;
            }
            ')' => {
                tokens.push(return_token(TokenType::CloseParen, ")".to_string()));
                i += 1;
            }
            '0'..='9' => {
                let mut num = String::new();
                let mut has_decimal = false;

                while i < chars.len() && (is_digit(chars[i]) || (!has_decimal && chars[i] == '.')) {
                    if chars[i] == '.' {
                        has_decimal = true;
                    }
                    num.push(chars[i]);
                    i += 1;
                }

                tokens.push(return_token(TokenType::Number, num));
            }
            'a'..='z' | 'A'..='Z' => {
                let mut ident = String::new();
                while i < chars.len() && (is_letter(chars[i]) || is_digit(chars[i])) {
                    ident.push(chars[i]);
                    i += 1;
                }
                // ADD KEYWORDS HERE
                if ident == "let" {
                    tokens.push(return_token(TokenType::Let, "let".to_string()));
                } else if ident == "const" {
                    tokens.push(return_token(TokenType::Const, "const".to_string()));
                } else { 
                    tokens.push(return_token(TokenType::Identifier, ident));
                }
            }
            '#' => {
                i += 1; // Skip comments
                while i < chars.len() && chars[i]!= '\n' {
                    i += 1;
                }
            }
            _ => {
                panic!("Unexpected character: {}", chars[i]);
            }
        }
    }

    tokens.push(return_token(TokenType::EOF, "EOF".to_string())); // Add EOF token at the end of the input
    tokens
}