// find the users operating system information\


pub fn os() -> (&'static str, &'static str) {
    let arch: &'static str = std::env::consts::ARCH;
    let os: &'static str = std::env::consts::OS;

   (arch, os)
}