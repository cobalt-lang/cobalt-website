#[derive(Clone, Debug, PartialEq)]
pub enum NodeType {
    Program,
    NumericLiteral,
    VarDeclaration,
    Identifier,
    BinaryExpr,
    AssignmentExpr,
}

// A single trait that encompasses both Stmt and Expr behavior.
pub trait Node: std::fmt::Debug {
    fn kind(&self) -> NodeType;
    fn as_any(&self) -> &dyn std::any::Any;
}

// Defines a block which contains many statements.
// Only one program will be contained in a file.
#[derive(Debug)]
pub struct Program {
    pub kind: NodeType,
    pub body: Vec<Box<dyn Node>>,
}

impl Node for Program {
    fn kind(&self) -> NodeType {
        self.kind.clone()
    }
    fn as_any(&self) -> &dyn std::any::Any {
        self
    }
}

// Assignment expression.
// Used to assign variables or a value of an object.
#[derive(Debug)]
pub struct AssignmentExpr {
    pub kind: NodeType,
    pub assignee: Box<dyn Node>,
    pub value: Box<dyn Node>,
}

impl Node for AssignmentExpr {
    fn kind(&self) -> NodeType {
        self.kind.clone()
    }
    fn as_any(&self) -> &dyn std::any::Any {
        self
    }
}

// An operation with two sides separated by an operator.
// Both sides can be ANY complex expression.
// Supported Operators -> + | - | / | * | %
#[derive(Debug)]
pub struct BinaryExpr {
    pub kind: NodeType,
    pub left: Box<dyn Node>,
    pub right: Box<dyn Node>,
    pub operator: String, // Consider defining an enum for binary operators
}

impl Node for BinaryExpr {
    fn kind(&self) -> NodeType {
        self.kind.clone()
    }
    fn as_any(&self) -> &dyn std::any::Any {
        self
    }
}

// Represents a user-defined variable or symbol in source.
#[derive(Debug)]
pub struct Identifier {
    pub kind: NodeType,
    pub symbol: String,
}

impl Node for Identifier {
    fn kind(&self) -> NodeType {
        self.kind.clone()
    }
    fn as_any(&self) -> &dyn std::any::Any {
        self
    }
}

// Represents a numeric constant inside the source code.
#[derive(Debug)]
pub struct NumericLiteral {
    pub kind: NodeType,
    pub value: String,
}

impl Node for NumericLiteral {
    fn kind(&self) -> NodeType {
        self.kind.clone()
    }
    fn as_any(&self) -> &dyn std::any::Any {
        self
    }
}

#[derive(Debug)]
pub struct VarDeclaration {
    pub kind: NodeType,
    pub constant: bool,
    pub identifier: String,
    pub value: Box<dyn Node>,
}

impl Node for VarDeclaration {
    fn kind(&self) -> NodeType {
        self.kind.clone()
    }
    fn as_any(&self) -> &dyn std::any::Any {
        self
    }
}