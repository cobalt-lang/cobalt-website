use crate::lexer::{lexer, Token, TokenType};
use crate::parser::ast::{self, Node, Program, VarDeclaration};

pub struct Parser {
    tokens: Vec<Token>,
    current: usize,
}

impl Parser {
    pub fn new() -> Self {
        Self {
            tokens: Vec::new(),
            current: 0,
        }
    }

    fn not_eof(&self) -> bool {
        self.current < self.tokens.len() && self.tokens[self.current].tokentype != TokenType::EOF
    }

    fn at(&self) -> &Token {
        &self.tokens[self.current]
    }

    fn eat(&mut self) -> Token {
        let token = self.tokens[self.current].clone();
        self.current += 1;
        token
    }

    fn expect(&mut self, token_type: TokenType, err: &str) -> Token {
        let token = self.eat();
        if token.tokentype != token_type {
            panic!("Parser Error: {}\nExpected: {:?}, Found: {:?}", err, token_type, token);
        }
        token
    }

    pub fn produce_ast(&mut self, source_code: &str) -> Program {
        self.tokens = lexer(source_code);
        let mut program = Program {
            kind: ast::NodeType::Program,
            body: Vec::new(),
        };

        while self.not_eof() {
            program.body.push(self.parse_stmt());
        }

        program
    }

    fn parse_stmt(&mut self) -> Box<dyn Node> {
        match self.at().tokentype {
            TokenType::Let => self.parse_var_declaration(),
            TokenType::Const => self.parse_var_declaration(),
            _ => self.parse_expr(),
        }
    }

    fn parse_var_declaration(&mut self) -> Box<dyn Node> {
        let is_constant = self.eat().tokentype == TokenType::Const;
        let identifier = self.expect(TokenType::Identifier, "Expected an identifier for a variable following the let | const keyword.").value;

        self.expect(TokenType::Equals, "Expected an equals sign after the variable name.");

        let declaration = VarDeclaration {
            kind: ast::NodeType::VarDeclaration,
            value: self.parse_expr(),
            identifier,
            constant: is_constant
        };

        Box::new(declaration)
    }

    fn parse_expr(&mut self) -> Box<dyn Node> {
        self.parse_assignment_expr()
    }

    fn parse_assignment_expr(&mut self) -> Box<dyn Node> {
        let left = self.parse_additive_expr(); // switch this with object expr when made
        
        if self.at().tokentype == TokenType::Equals {
            self.eat();
            let value = self.parse_assignment_expr();
            return Box::new(ast::AssignmentExpr {
                kind: ast::NodeType::AssignmentExpr,
                assignee: left,
                value,
            })
        }

        left
    }

    fn parse_additive_expr(&mut self) -> Box<dyn Node> {
        let mut left = self.parse_multiplicative_expr();

        while self.at().value == "+" || self.at().value == "-" {
            let operator = self.eat().value;
            let right = self.parse_multiplicative_expr();
            left = Box::new(ast::BinaryExpr {
                kind: ast::NodeType::BinaryExpr,
                left,
                right,
                operator,
            });
        }

        left
    }

    fn parse_multiplicative_expr(&mut self) -> Box<dyn Node> {
        let mut left = self.parse_primary_expr();

        while self.at().value == "/" || self.at().value == "*" || self.at().value == "%" {
            let operator = self.eat().value;
            let right = self.parse_primary_expr();
            left = Box::new(ast::BinaryExpr {
                kind: ast::NodeType::BinaryExpr,
                left,
                right,
                operator,
            });
        }

        left
    }

    fn parse_primary_expr(&mut self) -> Box<dyn Node> {
        match self.at().tokentype {
            TokenType::Identifier => {
                let symbol = self.eat().value;
                Box::new(ast::Identifier {
                    kind: ast::NodeType::Identifier,
                    symbol,
                })
            }
            TokenType::Number => {
                let value = self.eat().value;
                Box::new(ast::NumericLiteral {
                    kind: ast::NodeType::NumericLiteral,
                    value,
                })
            }
            TokenType::OpenParen => {
                self.eat();
                let expr = self.parse_expr();
                self.expect(
                    TokenType::CloseParen,
                    "Unexpected token found inside parenthesized expression. Expected closing parenthesis.",
                );
                expr
            }
            _ => panic!("Unexpected token found during parsing: {:?}", self.at()),
        }
    }
}
