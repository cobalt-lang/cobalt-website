mod lexer;
mod parser;
mod interpreter;

mod user;

use parser::parser::Parser;

// todo tomorrow
// add assignment expression | ident = 123 // assign a new value to the thingy

fn main() {
    let (user_arch, user_os) = user::os::os();

    let input: &str = "let gyat = 3 \n gyat = 7 \n gyat + rizzler";
    let tokens = lexer::lexer(input);
    let mut parser = Parser::new();
    let ast = parser.produce_ast(input);
    let mut env_ = interpreter::environment::environment::Environment::new(None);
    let _ = env_.declare_var("rizzler".to_string(), interpreter::values::mk_number(123.0), true);
    let _ = env_.declare_var("true".to_string(), interpreter::values::mk_bool(true), true);
    let _ = env_.declare_var("false".to_string(), interpreter::values::mk_bool(false), true);
    let _ = env_.declare_var("null".to_string(), interpreter::values::mk_null(), true);
    let interpreted = interpreter::interpreter::eval_program(&ast, &mut env_);

    println!("Tokens: {:#?}", tokens);
    println!("AST: {:?}", ast);
    println!("Interpreted: {:?}", interpreted);
    println!("User's Architecture: {}", user_arch);
    println!("User's OS: {}", user_os);
}