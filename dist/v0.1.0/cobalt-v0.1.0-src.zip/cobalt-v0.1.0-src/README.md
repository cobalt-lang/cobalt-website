| Release  | Status              | Codename     |Initial Release | Active LTS Start | Maintenance Start | End-of-life               |
| :--:     | :---:               | :---:        | :---:          | :---:            | :---:             | :---:                     |
| 0.x      | **Current**         | TBD          | TBD            | TBD              | TBD               | TBD                       |
| 1.x      | **Coming Soon**     | TBD          | TBD            | TBD              | TBD               | TBD                       |